<?php

error_reporting(E_ALL);

//*****************************************************************
// tools

function newobj($t) {
   $x = new stdClass;
   foreach ($t as $k => $v)
      $x->$k = $v;
   return $x;
}

function strip_underscore_fields($t) {
   $x = new stdClass;
   foreach ($t as $k => $v) {
      $newk = substr($k, 1);
      $x->$newk = $v;
   }
   return $x;
}

function db_decode($s) {
   return addslashes($s);
   //return htmlentities($s);
   //return $s;
   //return htmlentities(utf8_decode($s));
}

//*****************************************************************

include_once '../../ext/highcharts-php/highcharts.php';
include_once '../../connect.php';


//*****************************************************************
// paramètres de la requête


function dataChartAnswers($db, $contestIDMin, $contestIDMax) {

   if ($contestIDMin == $contestIDMax) {
      // récupération du nom du niveau
      $query = "SELECT name FROM `contest` WHERE `contest`.id = :ID";
      $stmt = $db->prepare($query);
      $stmt->execute(array(':ID' => $contestIDMin));
      $results = $stmt->fetch(PDO::FETCH_OBJ);
      if ($results === FALSE) 
        die("contest does not exist");
      $contestName = db_decode($results->name);
   } else {
      $contestName = "Résultats contestIDs $contestIDMin à $contestIDMax";
   }

   // récupération du nombre de participants sur l'épreuve

   $query = "SELECT COUNT(*) as nbTeamsTotal
   FROM `team` WHERE 
         `team`.cached_officialForContestID >= :idMin
     AND `team`.cached_officialForContestID <= :idMax";
   $stmt = $db->prepare($query);
   $stmt->execute(array(':idMin' => $contestIDMin, ':idMax' => $contestIDMax));
   $results = $stmt->fetch(PDO::FETCH_OBJ);
   if ($results === FALSE) 
     die("no teams on this");
   $nbTeamsTotal = $results->nbTeamsTotal;
   //var_dump($nbTeamsTotal);

   // récupération du nombre de bonnes réponses

   $query = "
   SELECT 
      `question`.ID as _questionID, 
      `question`.name as _name,
      `contest_question`.maxScore as _maxScore,
      (SELECT COUNT(*) FROM `team`, `team_question`
       WHERE `team`.cached_officialForContestID >= :idMin
         AND `team`.cached_officialForContestID <= :idMax
         AND `team_question`.questionID = _questionID
         AND `team_question`.teamID = `team`.id
         AND `team_question`.score = _maxScore
       ) as _nbTeamsCorrect,
      (SELECT COUNT(*) FROM `team`, `team_question`
       WHERE `team`.cached_officialForContestID >= :idMin
         AND `team`.cached_officialForContestID <= :idMax
         AND `team_question`.questionID = _questionID
         AND `team_question`.teamID = `team`.id
         AND `team_question`.score < _maxScore
         AND `team_question`.answer <> ''
       ) as _nbTeamsIncorrect
   FROM `contest_question`, `question`
   WHERE `contest_question`.contestID >= :idMin
   AND `contest_question`.contestID <= :idMax
   AND `contest_question`.questionID = `question`.id
   ";

   $stmt = $db->prepare($query);
   $stmt->execute(array(':idMin' => $contestIDMin, ':idMax' => $contestIDMax));
   $results = $stmt->fetchAll(PDO::FETCH_OBJ);
   if ($results === FALSE) 
     die("no tasks");
   $tasks = array();
   foreach ($results as $row) 
      $tasks[] = strip_underscore_fields($row);

   return newobj(array(
      'contestName' => $contestName,
      'nbTeamsTotal' => $nbTeamsTotal,
      'tasks' => $tasks));
}


//*****************************************************************
//*****************************************************************

function cmp_task_ratio($a, $b) {
    return $b->correctRatio - $a->correctRatio;
}

function prepareChartAnswers(& $data) {

   // préparation des données
   foreach($data->tasks as $task) {
      $task->correctRatio = round((100.0 * $task->nbTeamsCorrect) / $data->nbTeamsTotal);
      $task->incorrectRatio = round((100.0 * $task->nbTeamsIncorrect) / $data->nbTeamsTotal);
   }
   usort($data->tasks, "cmp_task_ratio");
   //var_dump($tasks);

   $series = array('labels' => array(), 'correct' => array(), 'incorrect' => array());

   foreach($data->tasks as $task) {
      $series['labels'][] = db_decode($task->name);
      $series['correct'][] = $task->correctRatio;
      $series['incorrect'][] = $task->incorrectRatio;
   }
   $data->series = $series;
}

function displayChartAnswersOptions(& $data, $chart_name) {
   return array(
   'chart' => array(
      'renderTo' => $chart_name,
      'defaultSeriesType' => 'column',
      ),
   'loading' => array(
      'hideDuration' => 0,
      ),
   'credits' => array(
      'text' => '',
      ),
   'tooltip' => array(
     'formatter' => new Javascript("
            function() {
              return '' + this.series.name +': '+ this.y + '%';
            }"),
      ),
    'plotOptions' => array(   
       'column' => array(
         'animation' => false,
         'stacking' => 'normal',
         'dataLabels' => array(
            'enabled' => true,
            'color' => 'white',
            'style' => array(
               'fontWeight' => 'bold'
               ),
            'formatter' => new Javascript("
                  function() {
                     return (this.y > 1) ? this.y +'%' : '';
                  }"),
            ),
         ),
      ),
   'title' => array(
      'text' => 'Réussite sur '.$data->contestName,
      ),
   'xAxis' => array(
      'categories' => $data->series['labels'],
      'labels' => array(
         'align' => 'right',
         'rotation' => -45,
         'style' => '',
         /*
         'align' => 'left',
         'rotation' => 45,
         */
         ),
      ),
   'yAxis' => array(
      'min' => 0,
      'max' => 100,
      'title' => array(
         'text' => 'Pourcentage des équipes participantes',
         ),
      ),
   'series' => array(
       array(
             'name' => 'Mauvaise réponse',
             'data' => $data->series['incorrect'],
             'legendIndex' => 1
             ),
       array(
             'name' => 'Bonne réponse',
             'data' => $data->series['correct'],
             'legendIndex' => 0
             )
       )
   );
}

function displayChartAnswers($series, $chart_name) {
   $options = displayChartAnswersOptions($series, $chart_name);
   $chartdescr = Highcharts::create($chart_name, $options);
   $chartdiv = '<div style="padding:0em" id="'.$chart_name.'" min-width="500" height="400"> </div>';
   //min-width="800" height="300 margin: 0 auto"
   return $chartdescr.$chartdiv;
}

function buildChartAnswers($db, $contestIDMin, $contestIDMax, & $cachedData) {
   $key = 'data_'.$contestIDMin.'_'.$contestIDMax;
   if (isset($cachedData[$key])) {
      $data = $cachedData[$key];
   } else {
      $data = dataChartAnswers($db, $contestIDMin, $contestIDMax);
      $cachedData[$key] = $data;
   }

   prepareChartAnswers($data);
   $chart_name = 'chart_answers_'.$key;
   return displayChartAnswers($data, $chart_name); 
}

function displayPage($body) {
echo <<<EOF
   <!DOCTYPE html>
   <html>
   <head>
   <meta charset='utf-8'>
   <script src='../../jquery-1.7.1.min.js'></script>
   <script src="../../ext/highcharts/js/highcharts.js"></script>
   <title>Castor - Admin - Statistiques</title>
   </head><body>
   $body
   </body></html>
EOF;
   }

   // <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>

   //<script src='jquery-combined.min.js?v=2'></script>



//*****************************************************************
// Settings

// select whether to perform query or use data stored in the file
$resetCache = false;
if (isset($_GET['reset']))
   $resetCache = $_GET['reset'];

$updateCache = $resetCache; // by default, update cache upon reset
if (isset($_GET['update']))
   $updateCache = $_GET['update'];

$cacheFile = 'stats_cache.php';

// select which contests to study
if (isset($_GET['contest'])) {
   $contestIDMin = $_GET['contest'];
   $nbLevels = 1;
} else { // default values
   $contestIDMin = 27;
   $nbLevels = 4;
}

$contestIDMax = $contestIDMin + $nbLevels - 1;


//*****************************************************************
// Display the page

// connect to $db (might not be necessary if cache available)

$db = connect();

// load cached data

$cachedData = array();
if (! $resetCache)
   $cachedData = unserialize(file_get_contents($cacheFile));

// compute charts

$body = '';
for ($contestID = $contestIDMin; $contestID <= $contestIDMax; $contestID++)
   $body .= buildChartAnswers($db, $contestID, $contestID, $cachedData);

/* --> il faudrait changer les requetes
if ($contestIDMin != $contestIDMax)
   $body .= buildChartAnswers($db, $contestIDMin, $contestIDMax, $cachedData);
*/

// store cached data

if ($updateCache) {
   file_put_contents($cacheFile, serialize($cachedData));
}

displayPage($body);


?>