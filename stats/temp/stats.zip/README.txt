

* Install a webserver (apache, mysql, php)
  so as to be able to load the plateform

* Edit php.ini so as to allow the script to take more time an memory, updateing to:
      max_execution_time = 1000     
      memory_limit = 1280M

* Make sure you configure connect.php properly at the root of the plateform

* Obtain a dump containing the appropriate tables (structure and data):
  contest, contest_question, group, question, team, team_question

* Load this dump:
    - clear the beaver table
    - run (with appropriate user/password, and sql filename)
         mysql -u root --password="" -e "source dump.sql" beaver

  Content of batch file to execute on windows (adjust path and username/password):
      echo drop database beaver; > command.txt
      echo CREATE DATABASE `beaver` >> command.txt
      PATH=%PATH%;C:\programs\wamp\bin\mysql\mysql5.6.12\bin
      mysql -u root --password="" < command.txt
      mysql -u root --password="" -e "source dump.sql" beaver
      pause

* Execute the following queries, which avoids complicated joins in the processing of team results
  (you might need to adjust the data, which corresponds to the date of end of the official contest):

   ALTER TABLE  `team` ADD  `cached_officialForContestID` INT( 11 ) NOT NULL AFTER  `cached_contestants` ,
   ADD INDEX ( `cached_officialForContestID` );

   UPDATE `team`, `group` 
   SET `team`.cached_officialForContestID = `group`.contestID
   WHERE `team`.groupID = `group`.id
   AND `team`.endTime < '2013-11-19 00:00:00'
   AND `group`.participationType = 'Official';

* Execute the following queries to add indices

   ALTER TABLE  `team_question` ADD INDEX (  `score` ) ;
   ALTER TABLE  `team_question` ADD INDEX (  `questionID` ) ;
   ALTER TABLE  `team_question` ADD INDEX (  `teamID` ) ;
   ALTER TABLE  `team` ADD INDEX (  `ID` ) ;
   ALTER TABLE  `team` ADD INDEX (  `participationType` ) ;
   ALTER TABLE  `team` ADD INDEX (  `cached_officialForContestID` ) ;
   ALTER TABLE  `contest_question` ADD INDEX (  `contestID` ) ;

* Open in a browser: admin/stats/stats.php?contest=27&update=1
   (where 27 is the id of the contest of interest)
   (update=1 indicates that data from database should be cached for next loading of the page)

  To force clearing the cache and reloading all data from the database, open:
     admin/stats/stats.php?contest=27&reset=1   




   